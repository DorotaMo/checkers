import pygame.mixer

pygame.mixer.init()
click_sound = pygame.mixer.Sound('sounds\click.wav')


# Button Class
class Button:
    BASE_COLOR = (0, 0, 0)
    HOVERING_COLOR = (255, 255, 255)

    def __init__(self, pos, width, height, text, font, hover_color=(255, 255, 255)):
        self.rect = pygame.Rect(pos[0], pos[1], width, height)
        self.text = text
        self.font = font
        self.current_color = self.BASE_COLOR
        self.HOVERING_COLOR = hover_color

    def draw(self, screen, mouse_pos):
        # Change color on hover
        self.current_color = self.HOVERING_COLOR if self.rect.collidepoint(mouse_pos) else self.BASE_COLOR
        pygame.draw.rect(screen, self.current_color, self.rect)

        # Render text
        text_color = (0, 0, 0) if self.current_color == self.HOVERING_COLOR else (255, 255, 255)
        text_surface = self.font.render(self.text, True, text_color)
        screen.blit(text_surface, (self.rect.x + 10, self.rect.y + 10))

    def is_clicked(self, mouse_pos):
        if self.rect.collidepoint(mouse_pos):
            click_sound.play()
            return True
        return False
