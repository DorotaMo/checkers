import pygame.mixer

from classes.button import Button
from classes.const import *
from classes.game import Game


class MainMenu:
    def __init__(self, screen, screen_w, screen_h):
        self.screen = screen
        self.screen_w = screen_w
        self.screen_h = screen_h

        # Offset to center the original 750x600 game area on screen
        self.ox = (screen_w - WIDTH) // 2
        self.oy = (screen_h - HEIGHT) // 2

        # Load assets
        self.background = pygame.image.load('images/board_background.jpg').convert_alpha()
        self.background = pygame.transform.scale(self.background, (HEIGHT // 8 * 9, HEIGHT))
        self.background.set_alpha(200)

        self.white_pawn = pygame.image.load('images/white_pawn.png').convert_alpha()
        self.black_pawn = pygame.image.load('images/red_pawn.png').convert_alpha()
        self.white_pawn = pygame.transform.scale(self.white_pawn, (120, 120))
        self.black_pawn = pygame.transform.scale(self.black_pawn, (120, 120))

        self.big_custom_font = pygame.font.Font('fonts/PressStart2P-Regular.ttf', 50)
        self.custom_font = pygame.font.Font('fonts/PressStart2P-Regular.ttf', 40)
        self.small_custom_font = pygame.font.Font('fonts/PressStart2P-Regular.ttf', 30)

    def cx(self, x):
        return self.ox + x

    def cy(self, y):
        return self.oy + y

    def main_menu(self):
        title_text = "Checkers"
        center_x = self.cx(WIDTH // 2)

        title = self.big_custom_font.render(title_text, True, (0, 0, 0))
        title_shadow_rect = title.get_rect(center=(center_x + 3, self.cy(118)))

        title_main = self.big_custom_font.render(title_text, True, (255, 255, 255))
        title_rect = title_main.get_rect(center=(center_x, self.cy(115)))

        buttons = [
            Button((self.cx(120), self.cy(255)), 500, 50, 'Start', self.small_custom_font),
            Button((self.cx(120), self.cy(315)), 500, 50, 'Exit', self.small_custom_font),
        ]

        buttons_background_rect = pygame.Rect(self.cx(100), self.cy(240), 540, 140)
        shadow_surface = pygame.Surface((540, 140), pygame.SRCALPHA)
        shadow_surface.fill((0, 0, 0, 150))

        while True:
            self.screen.fill((0, 0, 0))
            self.screen.blit(self.background, (self.cx(35), self.cy(0)))
            self.screen.blit(title, title_shadow_rect)
            self.screen.blit(title_main, title_rect)
            self.screen.blit(self.white_pawn, (title_rect.left - 120, title_rect.centery - 70))
            self.screen.blit(self.black_pawn, (title_rect.right + 1, title_rect.centery - 66))

            self.screen.blit(shadow_surface, (buttons_background_rect.x + 5, buttons_background_rect.y + 5))
            pygame.draw.rect(self.screen, (0, 0, 0), buttons_background_rect)
            pygame.draw.rect(self.screen, (230, 230, 230), buttons_background_rect, 3)

            mouse_pos = pygame.mouse.get_pos()
            for button in buttons:
                button.draw(self.screen, mouse_pos)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if buttons[0].is_clicked(mouse_pos):
                        self.game_mode()
                    elif buttons[1].is_clicked(mouse_pos):
                        return

            pygame.display.flip()

    def game_mode(self):
        center_x = self.cx(WIDTH // 2)

        text1 = self.big_custom_font.render("Choose", True, (255, 255, 255))
        text2 = self.big_custom_font.render("Game Mode", True, (255, 255, 255))
        text_rect1 = text1.get_rect(center=(center_x, self.cy(100)))
        text_rect2 = text2.get_rect(center=(center_x, self.cy(160)))

        buttons = [
            Button((self.cx(120), self.cy(230)), 500, 50, 'Player vs Player', self.small_custom_font),
            Button((self.cx(120), self.cy(280)), 500, 50, 'Player vs AI', self.small_custom_font),
            Button((self.cx(120), self.cy(450)), 500, 50, 'Return', self.small_custom_font),
        ]

        while True:
            self.screen.fill((0, 0, 0))
            mouse_pos = pygame.mouse.get_pos()
            self.screen.blit(text1, text_rect1)
            self.screen.blit(text2, text_rect2)
            for button in buttons:
                button.draw(self.screen, mouse_pos)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if buttons[0].is_clicked(mouse_pos):
                        game = Game(self.screen, self.small_custom_font)
                        game.game_loop()
                        return
                    elif buttons[1].is_clicked(mouse_pos):
                        self.game_difficulty()
                        return
                    elif buttons[2].is_clicked(mouse_pos):
                        return

            pygame.display.flip()

    def game_difficulty(self):
        center_x = self.cx(WIDTH // 2)

        text1 = self.big_custom_font.render("Choose", True, (255, 255, 255))
        text2 = self.big_custom_font.render("Difficulty", True, (255, 255, 255))
        text_rect1 = text1.get_rect(center=(center_x, self.cy(100)))
        text_rect2 = text2.get_rect(center=(center_x, self.cy(160)))

        buttons = [
            Button((self.cx(120), self.cy(230)), 500, 50, 'Easy', self.small_custom_font),
            Button((self.cx(120), self.cy(280)), 500, 50, 'Medium', self.small_custom_font),
            Button((self.cx(120), self.cy(330)), 500, 50, 'Hard', self.small_custom_font),
            Button((self.cx(120), self.cy(450)), 500, 50, 'Return', self.small_custom_font),
        ]

        while True:
            self.screen.fill((0, 0, 0))
            mouse_pos = pygame.mouse.get_pos()
            self.screen.blit(text1, text_rect1)
            self.screen.blit(text2, text_rect2)
            for button in buttons:
                button.draw(self.screen, mouse_pos)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if buttons[0].is_clicked(mouse_pos):
                        game = Game(self.screen, self.small_custom_font, game_mode='ai', depth=0)
                        game.game_loop()
                        return
                    elif buttons[1].is_clicked(mouse_pos):
                        game = Game(self.screen, self.small_custom_font, game_mode='ai', depth=3)
                        game.game_loop()
                        return
                    elif buttons[2].is_clicked(mouse_pos):
                        game = Game(self.screen, self.small_custom_font, game_mode='ai', depth=7)
                        game.game_loop()
                        return
                    elif buttons[3].is_clicked(mouse_pos):
                        return

            pygame.display.flip()


# Main Execution
if __name__ == "__main__":
    pygame.init()
    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    SCREEN_W, SCREEN_H = screen.get_size()
    pygame.display.set_caption('Checkers')
    menu = MainMenu(screen, SCREEN_W, SCREEN_H)
    menu.main_menu()
    pygame.quit()
